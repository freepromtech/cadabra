from django.contrib import admin
from cases.models import Case


admin.site.register(Case)
