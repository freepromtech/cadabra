from django.contrib import admin
from contacts.models import Contact

admin.site.register(Contact)
